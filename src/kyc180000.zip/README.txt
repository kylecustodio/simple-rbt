Kyle Custodio | KYC180000
Project 4
    RedBlackTree.java
    RBTDriver.java
JetBrains JDK 11

ex.

java RBTDriver C:/.../input.txt C:/.../output.txt

input.txt
    Integer
    Insert:98
    Insert:-68
    Insert:55
    Insert:45
    PrintTree
    Contains:45
    Insert:84
    Insert:32
    Insert:132
    Insert:45
    PrintTree
    Insert
    hih

=> output.txt
    True
    True
    True
    True
    55 -68 *45 98
    True
    True
    True
    True
    False
    55 32 *-68 *45 98 *84 *132
    Error in line:Insert
    Error in line:hih

